class Person:

    def fullName(self):
        return self.firstName + self.lastName

    def som(self):
        if True:
            print('something')
x = 5
x += 1
y = 1
x += 1