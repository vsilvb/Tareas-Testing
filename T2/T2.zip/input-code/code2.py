
class Person:
    
    def fullName(self):
        return self.firstName + self.lastName
    
    def som(self):
        if True:
            print("something")
        else: 
            pass

x = 5 
x = x + 1 
y = 1
x += 1